import { NextResponse } from "next/server"
import { getWeatherData, getWeatherAlerts, getWeatherForecast } from "../../lib/api"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const location = searchParams.get("location")

  if (!location) {
    return NextResponse.json({ error: "Location parameter is required" }, { status: 400 })
  }

  try {
    const [weather, alerts, forecast] = await Promise.all([
      getWeatherData(location),
      getWeatherAlerts(location),
      getWeatherForecast(location),
    ])

    return NextResponse.json({
      weather,
      alerts,
      forecast,
    })
  } catch (error) {
    console.error("Error fetching weather data:", error)
    return NextResponse.json({ error: "Failed to fetch weather data" }, { status: 500 })
  }
}

