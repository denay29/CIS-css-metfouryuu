export type WeatherData = {
  location: string
  temperature: number
  rainfall_probability: number
  wind_speed: number
  humidity: number
  condition: string
  description: string
  icon: string
}

export type Coordinates = {
  lat: number
  lon: number
}

export type WeatherAlert = {
  event: string
  description: string
  start: number
  end: number
}

