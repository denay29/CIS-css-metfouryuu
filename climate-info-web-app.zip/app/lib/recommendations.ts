import type { WeatherData } from "../types/weather"

type Recommendation = {
  title: string
  description: string
  color: string
}

type PestWarning = {
  description: string
}

export function generateRecommendations(weatherData: WeatherData): Recommendation[] {
  const recommendations: Recommendation[] = []

  // Rainfall-based recommendations
  if (weatherData.rainfall_probability <= 20) {
    recommendations.push({
      title: "Pamamahala ng Tubig",
      description:
        "Mababa ang tsansa ng ulan. Magsagawa ng mga sumusunod: 1) Maglagay ng patubig sa umaga o gabi para maiwasan ang mabilis na pagsingaw. 2) Gumamit ng drip irrigation para sa mas mahusay na paggamit ng tubig. 3) Maglagay ng organic mulch (tulad ng dayami o tuyong dahon) sa paligid ng mga halaman para mapanatili ang halumigmig ng lupa.",
      color: "bg-yellow-100",
    })
  } else if (weatherData.rainfall_probability <= 50) {
    recommendations.push({
      title: "Paghahanda sa Posibleng Pag-ulan",
      description:
        "May katamtamang tsansa ng ulan. Maghanda ng mga sumusunod: 1) Ihanda ang mga panakip para sa mga sensitibong pananim. 2) Suriin at linisin ang mga daluyan ng tubig para maiwasan ang pagbaha. 3) Maghanda ng mga organic na pataba na maaaring gamitin pagkatapos ng ulan para sa mas mabilis na paglago ng mga halaman.",
      color: "bg-green-100",
    })
  } else {
    recommendations.push({
      title: "Pag-iingat sa Malakas na Ulan",
      description:
        "Mataas ang tsansa ng ulan. Magsagawa ng mga sumusunod: 1) Tiyakin na maayos ang drainage system sa bukid. 2) Maglagay ng mga harang o windbreaks para maprotektahan ang mga pananim mula sa malakas na hangin at ulan. 3) Kung posible, mag-ani na ng mga hinog na pananim para maiwasan ang pinsala. 4) Maghanda ng mga organic na fungicide para maiwasan ang pagkakaroon ng amag sa mga halaman.",
      color: "bg-blue-100",
    })
  }

  // Temperature-based recommendations
  if (weatherData.temperature <= 20) {
    recommendations.push({
      title: "Pangangalaga sa Malamig na Panahon",
      description:
        "Malamig ang panahon. Isagawa ang mga sumusunod: 1) Maglagay ng mga pantakip o gumamit ng greenhouse para sa mga sensitibong tanim. 2) Bawasan ang pagdidilig dahil mabagal ang pagsingaw ng tubig sa malamig na panahon. 3) Maglagay ng organic na mulch para panatilihing mainit ang lupa. 4) Magtanim ng mga gulay na mahilig sa malamig na klima tulad ng repolyo, carrots, at broccoli.",
      color: "bg-blue-100",
    })
  } else if (weatherData.temperature <= 30) {
    recommendations.push({
      title: "Pangangalaga sa Katamtamang Temperatura",
      description:
        "Katamtamang init ang panahon. Magandang pagkakataon ito para: 1) Magtanim ng iba't ibang uri ng gulay at prutas. 2) Magsagawa ng regular na pagdidilig, lalo na sa mga oras ng umaga. 3) Maglagay ng compost o organic na pataba para sa mas magandang ani. 4) Suriin ang mga halaman para sa mga senyales ng peste o sakit dahil mabilis ang pagdami ng mga ito sa ganitong temperatura.",
      color: "bg-green-100",
    })
  } else {
    recommendations.push({
      title: "Pangangalaga sa Mainit na Panahon",
      description:
        "Mainit ang panahon. Mahalaga ang mga sumusunod: 1) Dagdagan ang dalas ng pagdidilig, mas mainam kung gumamit ng drip irrigation. 2) Maglagay ng shade cloth o gumamit ng row covers para maprotektahan ang mga halaman mula sa matinding init. 3) Maglagay ng mulch para mapanatili ang halumigmig ng lupa. 4) Magtanim ng mga halamang matibay sa init tulad ng okra, kamote, at sitaw.",
      color: "bg-yellow-100",
    })
  }

  // Wind-based recommendations
  if (weatherData.wind_speed > 30) {
    recommendations.push({
      title: "Pag-iingat sa Malakas na Hangin",
      description:
        "Malakas ang hangin. Magsagawa ng mga sumusunod: 1) Maglagay ng mga windbreaks o harang sa hangin gamit ang mga matatag na halaman o artificial na materyales. 2) Patibayin ang mga suporta ng mga gulay na may hawakan tulad ng sitaw at ampalaya. 3) Iwasang mag-spray ng pestisidyo o pataba dahil maaaring tangayin ito ng hangin. 4) Protektahan ang mga bagong tanim na seedlings gamit ang mga panakip.",
      color: "bg-orange-100",
    })
  }

  // Humidity-based recommendations
  if (weatherData.humidity > 80) {
    recommendations.push({
      title: "Pangangalaga sa Mataas na Halumigmig",
      description:
        "Mataas ang halumigmig. Mahalaga ang mga sumusunod: 1) Dagdagan ang espasyo sa pagitan ng mga halaman para sa mas mahusay na sirkulasyon ng hangin. 2) Magbawas sa overhead watering at mas magfocus sa root-level irrigation. 3) Regular na suriin ang mga halaman para sa mga senyales ng fungal diseases. 4) Maghanda ng organic na fungicide bilang pag-iingat.",
      color: "bg-blue-100",
    })
  } else if (weatherData.humidity < 40) {
    recommendations.push({
      title: "Pangangalaga sa Mababang Halumigmig",
      description:
        "Mababa ang halumigmig. Isagawa ang mga sumusunod: 1) Dagdagan ang dalas ng pagdidilig, mas mainam sa umaga o gabi. 2) Gumamit ng mulch para mapanatili ang halumigmig ng lupa. 3) Maglagay ng mga halaman na magkakalapit para gumawa ng microclimate. 4) Iwasang gumalaw ng lupa para maiwasan ang pagkawala ng halumigmig.",
      color: "bg-yellow-100",
    })
  }

  return recommendations
}

export function generatePestWarnings(weatherData: WeatherData): PestWarning[] {
  const warnings: PestWarning[] = []

  if (weatherData.temperature > 25 && weatherData.humidity > 80) {
    warnings.push({
      description:
        "Babala! Mataas ang posibilidad ng amag sa mga gulay. Magsagawa ng mga sumusunod: 1) Bawasan ang overhead watering. 2) Alisin ang mga infected na dahon o bunga. 3) Mag-spray ng natural na fungicide gaya ng baking soda solution (1 kutsarang baking soda sa 1 litrong tubig).",
    })
  }

  if (weatherData.temperature > 30 && weatherData.humidity < 50) {
    warnings.push({
      description:
        "Mag-ingat! Ang mainit at tuyong panahon ay paborable para sa mga insekto tulad ng aphids at spider mites. Gawin ang mga sumusunod: 1) Regular na suriin ang ilalim ng mga dahon. 2) Mag-spray ng mahinang sabon solution (2 kutsarang dishwashing liquid sa 1 litrong tubig) sa mga apektadong parte. 3) Maglagay ng beneficial insects tulad ng lady bugs.",
    })
  }

  if (weatherData.rainfall_probability > 70 && weatherData.temperature > 20) {
    warnings.push({
      description:
        "Babala! Ang malamig at maulang panahon ay maaaring magdulot ng late blight sa mga kamatis at patatas. Isagawa ang mga sumusunod: 1) Bawasan ang overhead watering. 2) Alisin at sunugin ang mga infected na parte ng halaman. 3) Mag-spray ng copper-based fungicide bilang pag-iingat. 4) Panatilihing malinis ang lugar sa palibot ng mga halaman.",
    })
  }

  return warnings
}

