import type { WeatherData, Coordinates, WeatherAlert } from "../types/weather"

const BASE_URL = "https://api.openweathermap.org/data/2.5"

async function fetchWithErrorHandling(url: string) {
  const response = await fetch(url)
  if (!response.ok) {
    const errorBody = await response.text()
    throw new Error(`Weather API error: ${response.status} ${response.statusText}\n${errorBody}`)
  }
  return await response.json()
}

async function getCoordinates(location: string): Promise<Coordinates> {
  const geocodingUrl = `http://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(
    location,
  )}&limit=1&appid=${process.env.OPENWEATHER_API_KEY}`

  const data = await fetchWithErrorHandling(geocodingUrl)

  if (!data.length) {
    throw new Error("Location not found")
  }

  return {
    lat: data[0].lat,
    lon: data[0].lon,
  }
}

export async function getWeatherData(location: string): Promise<WeatherData> {
  try {
    const coords = await getCoordinates(location)

    const weatherUrl = `${BASE_URL}/weather?lat=${coords.lat}&lon=${coords.lon}&units=metric&appid=${process.env.OPENWEATHER_API_KEY}`
    const data = await fetchWithErrorHandling(weatherUrl)

    if (!data.main || !data.weather || data.weather.length === 0) {
      throw new Error("Unexpected API response structure")
    }

    return {
      location: location,
      temperature: Math.round(data.main.temp),
      rainfall_probability: data.clouds?.all ?? 0,
      wind_speed: Math.round((data.wind?.speed ?? 0) * 3.6),
      humidity: data.main.humidity,
      condition: data.weather[0].main.toLowerCase(),
      description: data.weather[0].description,
      icon: data.weather[0].icon,
    }
  } catch (error) {
    console.error("Error in getWeatherData:", error)
    throw error
  }
}

export async function getWeatherAlerts(location: string): Promise<WeatherAlert[]> {
  const coords = await getCoordinates(location)

  // Get one-call API data which includes alerts
  const oneCallUrl = `${BASE_URL}/onecall?lat=${coords.lat}&lon=${coords.lon}&exclude=minutely,hourly,daily&appid=${process.env.OPENWEATHER_API_KEY}`
  const data = await fetchWithErrorHandling(oneCallUrl)

  if (!data.alerts) {
    return [] // Return empty array if no alerts
  }

  return data.alerts.map((alert: any) => ({
    event: alert.event,
    description: alert.description,
    start: alert.start,
    end: alert.end,
  }))
}

// New function to get forecast data
export async function getWeatherForecast(location: string) {
  const coords = await getCoordinates(location)

  const forecastUrl = `${BASE_URL}/forecast?lat=${coords.lat}&lon=${coords.lon}&units=metric&appid=${process.env.OPENWEATHER_API_KEY}`
  const data = await fetchWithErrorHandling(forecastUrl)

  return data.list.map((item: any) => ({
    timestamp: item.dt * 1000, // Convert to milliseconds
    temperature: Math.round(item.main.temp),
    condition: item.weather[0].main.toLowerCase(),
    description: item.weather[0].description,
    icon: item.weather[0].icon,
  }))
}

export async function predictWeather(location: string, days = 5): Promise<WeatherData[]> {
  const coords = await getCoordinates(location)

  const forecastUrl = `${BASE_URL}/forecast?lat=${coords.lat}&lon=${coords.lon}&units=metric&appid=${process.env.OPENWEATHER_API_KEY}`
  const data = await fetchWithErrorHandling(forecastUrl)

  // Group forecast data by day
  const dailyForecasts = data.list.reduce((acc: any, forecast: any) => {
    const date = new Date(forecast.dt * 1000).toDateString()
    if (!acc[date]) {
      acc[date] = []
    }
    acc[date].push(forecast)
    return acc
  }, {})

  // Calculate daily averages
  const predictions = Object.entries(dailyForecasts)
    .slice(0, days)
    .map(([date, forecasts]: [string, any[]]) => {
      const avgTemp = forecasts.reduce((sum, f) => sum + f.main.temp, 0) / forecasts.length
      const avgHumidity = forecasts.reduce((sum, f) => sum + f.main.humidity, 0) / forecasts.length
      const avgWindSpeed = forecasts.reduce((sum, f) => sum + f.wind.speed, 0) / forecasts.length
      const rainProbability = (forecasts.filter((f) => f.rain && f.rain["3h"]).length / forecasts.length) * 100

      const mostCommonWeather = forecasts
        .map((f) => f.weather[0].main)
        .sort(
          (a, b) =>
            forecasts.filter((f) => f.weather[0].main === a).length -
            forecasts.filter((f) => f.weather[0].main === b).length,
        )
        .pop()

      return {
        date: new Date(date),
        location: location,
        temperature: Math.round(avgTemp),
        rainfall_probability: Math.round(rainProbability),
        wind_speed: Math.round(avgWindSpeed * 3.6), // Convert to km/h
        humidity: Math.round(avgHumidity),
        condition: mostCommonWeather.toLowerCase(),
        description: `Predicted ${mostCommonWeather.toLowerCase()} weather`,
        icon: forecasts[0].weather[0].icon, // Use the icon from the first forecast of the day
      }
    })

  return predictions
}

// Add this function to get both current weather and predictions
export async function getWeatherWithPredictions(
  location: string,
): Promise<{ current: WeatherData; predictions: WeatherData[] }> {
  const [current, predictions] = await Promise.all([getWeatherData(location), predictWeather(location)])

  return { current, predictions }
}

