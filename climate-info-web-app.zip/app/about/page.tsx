import Link from "next/link"

export default function AboutPage() {
  return (
    <main className="flex min-h-screen flex-col items-center p-4 md:p-24">
      <h1 className="text-4xl font-bold text-green-800 mb-8">Tungkol sa Climate Information Web App</h1>

      <div className="w-full max-w-3xl space-y-8">
        <section>
          <h2 className="text-2xl font-semibold text-green-700 mb-4">Ano ang layunin ng web app na ito?</h2>
          <p>
            Ang Climate Information Web App ay dinisenyo upang tulungan ang mga magsasakang Pilipino na umangkop sa
            nagbabagong klima. Ginagamit nito ang pinasimpleng datos ng panahon at mga payo sa pagsasaka para magbigay
            ng kapaki-pakinabang na impormasyon.
          </p>
          <p className="mt-2">
            Sa panahon ng pabago-bagong klima, mahalaga na maunawaan ng mga magsasaka kung ano ang dapat gawin upang
            maprotektahan ang kanilang pananim.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-green-700 mb-4">Saan galing ang impormasyon?</h2>
          <ul className="list-disc list-inside space-y-2">
            <li>Ang real-time na datos ng panahon ay kinukuha mula sa OpenWeatherMap API.</li>
            <li>
              Ang mga rekomendasyon sa pagsasaka ay batay sa mga siyentipikong pag-aaral sa agrikultura, mga modelo ng
              klima, at mga insight na ibinahagi ng komunidad.
            </li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-green-700 mb-4">Paano kinakalkula ang rekomendasyon?</h2>
          <p>Ang aming algorithm ay gumagana sa sumusunod na paraan:</p>
          <ol className="list-decimal list-inside space-y-2 mt-2">
            <li>
              Sinusuri nito ang kasalukuyang datos ng panahon (temperatura, pag-ulan, halumigmig, bilis ng hangin).
            </li>
            <li>Inihahambing ito sa pinakamahusay na mga gawain sa agrikultura para sa naturang kondisyon ng klima.</li>
            <li>
              Binibigyang-priyoridad nito ang simpleng, magagamit na payo sa Tagalog (hal., mga iskedyul ng pagtatanim,
              kontrol sa peste, mga tip sa paghahanda).
            </li>
          </ol>
          <p className="mt-2">Halimbawa:</p>
          <ul className="list-disc list-inside space-y-2 mt-2">
            <li>
              Kung mataas ang pag-ulan → Irerekumenda ang "pagtatanim ng mga halamang kayang mabuhay sa maraming tubig
              tulad ng palay."
            </li>
            <li>
              Kung may malakas na hangin → Magmumungkahi ng "paggamit ng windbreaks upang maprotektahan ang pananim."
            </li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-green-700 mb-4">
            Ano ang "Biglaang Babala" (Drastic Weather Alerts)?
          </h2>
          <p>
            Ang app ay may kakayahang matukoy ang mga biglaang pagbabago sa panahon at mag-abiso sa mga magsasaka upang
            makapaghanda. Halimbawa, kung biglang bumaba ang temperatura nang lampas sa normal, ipapaalam ng app na
            kailangan maghanda ng proteksyon para sa mga hayop at pananim.
          </p>
        </section>

        <Link
          href="/"
          className="inline-block mt-8 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors"
        >
          Bumalik sa Home
        </Link>
      </div>
    </main>
  )
}

