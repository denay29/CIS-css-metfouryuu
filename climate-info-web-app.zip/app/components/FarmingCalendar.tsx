"use client"

import { useState, useEffect } from "react"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CropSuggestion = {
  month: number
  crops: string[]
}

const mockCropSuggestions: CropSuggestion[] = [
  { month: 0, crops: ["Sibuyas", "Bawang", "Patatas"] },
  { month: 1, crops: ["Kamatis", "Talong", "Sili"] },
  { month: 2, crops: ["Mais", "Monggo", "Sitaw"] },
  { month: 3, crops: ["Kalabasa", "Ampalaya", "Okra"] },
  { month: 4, crops: ["Palay", "Kamote", "Kasoy"] },
  { month: 5, crops: ["Saging", "Pinya", "Papaya"] },
  { month: 6, crops: ["Kangkong", "Pechay", "Mustasa"] },
  { month: 7, crops: ["Labanos", "Carrots", "Repolyo"] },
  { month: 8, crops: ["Patola", "Upo", "Singkamas"] },
  { month: 9, crops: ["Kamatis", "Sibuyas", "Bawang"] },
  { month: 10, crops: ["Palay", "Mais", "Kamote"] },
  { month: 11, crops: ["Sili", "Talong", "Sitaw"] },
]

export default function FarmingCalendar({ location }: { location: string }) {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [suggestions, setSuggestions] = useState<string[]>([])

  useEffect(() => {
    if (date) {
      const month = date.getMonth()
      const suggestion = mockCropSuggestions.find((s) => s.month === month)
      setSuggestions(suggestion ? suggestion.crops : [])
    }
  }, [date])

  return (
    <Card className="w-full max-w-md mt-8">
      <CardHeader>
        <CardTitle>Kalendaryo ng Pagtatanim para sa {location}</CardTitle>
        <CardDescription>Piliin ang petsa para makita ang mga iminumungkahing pananim</CardDescription>
      </CardHeader>
      <CardContent>
        <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md border" />
        {date && (
          <div className="mt-4">
            <h3 className="font-semibold">
              Mga Iminumungkahing Pananim para sa {date.toLocaleString("tl-PH", { month: "long" })}:
            </h3>
            <ul className="list-disc list-inside mt-2">
              {suggestions.map((crop, index) => (
                <li key={index}>{crop}</li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

