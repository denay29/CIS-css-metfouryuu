"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cropData } from "../lib/cropData"

export default function CropList() {
  const [selectedCrop, setSelectedCrop] = useState<string | null>(null)

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {Object.entries(cropData).map(([key, crop]) => (
          <Button
            key={key}
            variant="outline"
            className="text-left justify-start h-auto py-2"
            onClick={() => setSelectedCrop(key)}
          >
            {crop.commonName} ({crop.vernacularNames[0]})
          </Button>
        ))}
      </div>
      {selectedCrop && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>
              {cropData[selectedCrop].commonName} ({cropData[selectedCrop].scientificName})
            </CardTitle>
            <CardDescription>
              Mga lokal na pangalan: {cropData[selectedCrop].vernacularNames.join(", ")}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p>
              <strong>Siklo ng Buhay:</strong> {cropData[selectedCrop].lifeCycle}
            </p>
            <p>
              <strong>Paraan ng Pagpaparami:</strong> {cropData[selectedCrop].reproduction}
            </p>
            <p>
              <strong>Uri ng Paglaki:</strong> {cropData[selectedCrop].growthHabit}
            </p>
            <p>
              <strong>Paglalarawan:</strong> {cropData[selectedCrop].description}
            </p>
            <p>
              <strong>Lugar ng Pagtatanim:</strong> {cropData[selectedCrop].cultivation}
            </p>
            <p>
              <strong>Mga Gamit:</strong>
            </p>
            <ul>
              {cropData[selectedCrop].uses.map((use, index) => (
                <li key={index}>{use}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
      <div className="mt-8">
        <Link href="/">
          <Button variant="outline">Bumalik sa Home</Button>
        </Link>
      </div>
    </div>
  )
}

