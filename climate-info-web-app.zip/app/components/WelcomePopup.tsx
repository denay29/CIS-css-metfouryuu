"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

const tourSteps = [
  {
    title: "Maligayang pagdating!",
    description: "Ito ang iyong gabay sa paggamit ng Climate Information Web App.",
  },
  {
    title: "Lokasyon",
    description: "Piliin ang iyong lokasyon para makakuha ng tiyak na impormasyon tungkol sa panahon.",
  },
  {
    title: "Mga Payo ng Magsasaka",
    description: "Makikita mo dito ang mga kapaki-pakinabang na payo mula sa ibang mga magsasaka.",
  },
  {
    title: "Magbahagi ng Sariling Payo",
    description: "Maaari kang magbahagi ng iyong sariling payo para sa ibang mga magsasaka.",
  },
  {
    title: "Kasaysayan ng Panahon",
    description: "Tingnan ang kasaysayan at trend ng panahon sa iyong lugar.",
  },
]

export function WelcomePopup() {
  const [isOpen, setIsOpen] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)

  useEffect(() => {
    const hasVisited = localStorage.getItem("hasVisitedBefore")
    if (!hasVisited) {
      setIsOpen(true)
      localStorage.setItem("hasVisitedBefore", "true")
    }
  }, [])

  const handleNext = () => {
    if (currentStep < tourSteps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      setIsOpen(false)
    }
  }

  const handleSkip = () => {
    setIsOpen(false)
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{tourSteps[currentStep].title}</DialogTitle>
          <DialogDescription>{tourSteps[currentStep].description}</DialogDescription>
        </DialogHeader>
        <div className="flex justify-between mt-4">
          <Button variant="outline" onClick={handleSkip}>
            Laktawan
          </Button>
          <Button onClick={handleNext}>{currentStep < tourSteps.length - 1 ? "Susunod" : "Tapos na"}</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

