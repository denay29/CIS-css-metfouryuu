"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export default function CommunityTips() {
  const [tips, setTips] = useState([
    { id: 1, author: "Juan", content: "Gumamit ng mulch para mapanatili ang halumigmig ng lupa." },
    { id: 2, author: "Maria", content: "Mag-crop rotation para maiwasan ang peste at sakit ng halaman." },
  ])
  const [newTip, setNewTip] = useState({ author: "", content: "" })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (newTip.author && newTip.content) {
      setTips([...tips, { id: tips.length + 1, ...newTip }])
      setNewTip({ author: "", content: "" })
    }
  }

  return (
    <div className="w-full max-w-md mt-8">
      <h2 className="text-2xl font-semibold text-green-800 mb-4">Mga Tip mula sa Komunidad</h2>
      <ul className="space-y-4">
        {tips.map((tip) => (
          <li key={tip.id} className="bg-white shadow rounded-lg p-4">
            <p className="font-semibold">{tip.author}</p>
            <p>{tip.content}</p>
          </li>
        ))}
      </ul>
      <form onSubmit={handleSubmit} className="mt-6">
        <Input
          type="text"
          placeholder="Iyong pangalan"
          value={newTip.author}
          onChange={(e) => setNewTip({ ...newTip, author: e.target.value })}
          className="mb-2"
        />
        <Textarea
          placeholder="Ibahagi ang iyong tip"
          value={newTip.content}
          onChange={(e) => setNewTip({ ...newTip, content: e.target.value })}
          className="mb-2"
        />
        <Button type="submit">Ibahagi ang Tip</Button>
      </form>
    </div>
  )
}

