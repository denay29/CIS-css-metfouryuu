"use client"

import { useState, useEffect } from "react"
import { getWeatherData } from "../lib/api"
import { generateRecommendations } from "../lib/recommendations"

export default function FarmingAdvice() {
  const [recommendations, setRecommendations] = useState([])

  useEffect(() => {
    const fetchRecommendations = async () => {
      try {
        const weatherData = await getWeatherData("Manila, Philippines")
        const recs = generateRecommendations(weatherData)
        setRecommendations(recs)
      } catch (error) {
        console.error("Error fetching recommendations:", error)
      }
    }
    fetchRecommendations()
  }, [])

  return (
    <div className="bg-white shadow-lg rounded-lg p-6 mt-8 w-full max-w-md">
      <h2 className="text-2xl font-semibold text-green-800 mb-4">Payo sa Pagsasaka</h2>
      {recommendations.map((rec, index) => (
        <div key={index} className={`p-4 rounded-lg ${rec.color} mb-4`}>
          <h3 className="font-semibold mb-2">{rec.title}</h3>
          <p>{rec.description}</p>
        </div>
      ))}
    </div>
  )
}

