"use client"

import { useState, useEffect } from "react"
import { AlertTriangle } from "lucide-react"
import { getWeatherAlerts } from "../lib/api"
import type { WeatherAlert } from "../types/weather"

export default function WeatherAlerts() {
  const [alerts, setAlerts] = useState<WeatherAlert[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        setLoading(true)
        // You might want to get this default location from user's preferences or geolocation
        const alertsData = await getWeatherAlerts("Manila, Philippines")
        setAlerts(alertsData)
      } catch (error) {
        console.error("Error fetching alerts:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchAlerts()

    // Refresh alerts every 5 minutes
    const interval = setInterval(fetchAlerts, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  if (loading || alerts.length === 0) return null

  return (
    <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-8 w-full max-w-md">
      <div className="flex items-center">
        <AlertTriangle className="h-6 w-6 mr-2" />
        <p className="font-bold">Mga Babala sa Panahon</p>
      </div>
      <ul className="mt-2 space-y-2">
        {alerts.map((alert, index) => (
          <li key={index} className="ml-8 list-disc">
            <p className="font-semibold">{alert.event}</p>
            <p className="text-sm">{alert.description}</p>
            <p className="text-xs mt-1">
              Mula: {new Date(alert.start * 1000).toLocaleString("tl-PH")}
              <br />
              Hanggang: {new Date(alert.end * 1000).toLocaleString("tl-PH")}
            </p>
          </li>
        ))}
      </ul>
    </div>
  )
}

