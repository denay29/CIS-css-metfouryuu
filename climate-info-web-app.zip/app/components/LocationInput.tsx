"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { MapPin } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"

export default function LocationInput() {
  const [location, setLocation] = useState("")
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (location) {
      router.push(`/recommendations?location=${encodeURIComponent(location)}`)
    }
  }

  const handleGeolocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords
          router.push(`/recommendations?lat=${latitude}&lon=${longitude}`)
        },
        (error) => {
          console.error("Error getting location:", error)
        },
      )
    } else {
      console.error("Geolocation is not supported by this browser.")
    }
  }

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-md mb-8 fade-in">
      <label htmlFor="location" className="block text-lg font-medium text-text-light mb-2">
        Lokasyon (Probinsya)
      </label>
      <div className="flex items-center">
        <Select value={location} onValueChange={setLocation}>
          <SelectTrigger id="location" className="flex-grow input">
            <SelectValue placeholder="Piliin ang iyong lokasyon" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Cavite">Cavite</SelectItem>
            <SelectItem value="Laguna">Laguna</SelectItem>
            <SelectItem value="Batangas">Batangas</SelectItem>
            <SelectItem value="Rizal">Rizal</SelectItem>
            <SelectItem value="Quezon">Quezon</SelectItem>
          </SelectContent>
        </Select>
        <Button type="submit" className="ml-2 btn btn-primary">
          Maghanap
        </Button>
      </div>
      <button
        type="button"
        onClick={handleGeolocation}
        className="mt-2 flex items-center text-primary hover:text-primary-dark transition-colors duration-300"
      >
        <MapPin className="w-4 h-4 mr-1" />
        Gamitin ang kasalukuyang lokasyon
      </button>
    </form>
  )
}

