"use client"

import { useState } from "react"
import { Calendar } from "@/components/ui/calendar"

export default function PlantingCalendar() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  return (
    <div className="w-full max-w-md mt-8">
      <h2 className="text-2xl font-semibold text-green-800 mb-4">Kalendaryo ng Pagtatanim</h2>
      <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md border" />
      {date && (
        <p className="mt-4">
          Piniling petsa:{" "}
          {date.toLocaleDateString("tl-PH", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
        </p>
      )}
      <p className="mt-2">Mainam magtanim ng palay sa piniling petsa.</p>
    </div>
  )
}

