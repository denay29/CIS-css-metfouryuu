import { MapPin, Thermometer, Droplet, Wind } from "lucide-react"
import type { WeatherData } from "../types/weather"

export default function WeatherSummary({ weatherData }: { weatherData: WeatherData }) {
  return (
    <div className="bg-white shadow-lg rounded-lg p-6 w-full">
      <h2 className="text-2xl font-semibold text-green-800 mb-4">Buod ng Panahon</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="flex items-center">
          <MapPin className="text-green-500 mr-2" />
          <span>{weatherData.location}</span>
        </div>
        <div className="flex items-center">
          <Thermometer className="text-red-500 mr-2" />
          <span>{weatherData.temperature}°C</span>
        </div>
        <div className="flex items-center">
          <Droplet className="text-blue-500 mr-2" />
          <span>{weatherData.rainfall_probability}% tsansa ng ulan</span>
        </div>
        <div className="flex items-center">
          <Wind className="text-gray-500 mr-2" />
          <span>{weatherData.wind_speed} km/h</span>
        </div>
        <div className="flex items-center">
          <Droplet className="text-blue-300 mr-2" />
          <span>{weatherData.humidity}% humidity</span>
        </div>
        <div className="flex items-center">
          <img
            src={`http://openweathermap.org/img/wn/${weatherData.icon}@2x.png`}
            alt={weatherData.description}
            className="w-8 h-8 mr-2"
          />
          <span className="capitalize">{weatherData.description}</span>
        </div>
      </div>
    </div>
  )
}

