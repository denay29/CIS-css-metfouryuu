"use client"

import { useState } from "react"
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet"
import "leaflet/dist/leaflet.css"

export default function InteractiveMap() {
  const [center, setCenter] = useState({ lat: 14.5995, lng: 120.9842 }) // Manila coordinates
  const zoom = 7

  return (
    <div className="w-full max-w-4xl mt-8">
      <h2 className="text-2xl font-semibold text-green-800 mb-4">Mapa ng Panahon</h2>
      <MapContainer center={center} zoom={zoom} className="h-96">
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        <Marker position={center}>
          <Popup>Manila, Philippines</Popup>
        </Marker>
      </MapContainer>
    </div>
  )
}

