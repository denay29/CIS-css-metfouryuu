"use client"

import { useState, useEffect } from "react"
import { Volume2, VolumeX } from "lucide-react"
import { Button } from "@/components/ui/button"

type TextToSpeechProps = {
  text: string
}

export default function TextToSpeech({ text }: TextToSpeechProps) {
  const [isSpeaking, setIsSpeaking] = useState(false)

  useEffect(() => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel()
    }
  }, []) // Removed unnecessary dependency 'text'

  const speak = () => {
    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = "tl-PH" // Set language to Tagalog
      utterance.onend = () => setIsSpeaking(false)
      window.speechSynthesis.speak(utterance)
      setIsSpeaking(true)
    }
  }

  const stop = () => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel()
      setIsSpeaking(false)
    }
  }

  return (
    <Button onClick={isSpeaking ? stop : speak} className="mt-4">
      {isSpeaking ? <VolumeX className="mr-2" /> : <Volume2 className="mr-2" />}
      {isSpeaking ? "Ihinto ang Pagbasa" : "Basahin ang Teksto"}
    </Button>
  )
}

