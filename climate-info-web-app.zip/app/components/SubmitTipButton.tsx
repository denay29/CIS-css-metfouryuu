"use client"

import { useState } from "react"
import { Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function SubmitTipButton() {
  const [open, setOpen] = useState(false)
  const [tip, setTip] = useState("")
  const [author, setAuthor] = useState("")
  const [category, setCategory] = useState("")

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault()
    // Here you would typically send the data to your backend
    console.log({ tip, author, category })
    setOpen(false)
    // Reset form
    setTip("")
    setAuthor("")
    setCategory("")
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="fixed bottom-4 right-4 rounded-full btn btn-primary">
          <Plus className="mr-2 h-4 w-4" /> Magbahagi ng Sariling Payo
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Magbahagi ng Sariling Payo</DialogTitle>
          <DialogDescription>
            Ibahagi ang iyong kaalaman sa ibang mga magsasaka. Ang iyong payo ay susuriin bago i-publish.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="tip" className="text-right">
                Payo
              </Label>
              <Textarea
                id="tip"
                value={tip}
                onChange={(e) => setTip(e.target.value)}
                className="col-span-3 input"
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="author" className="text-right">
                Pangalan
              </Label>
              <Input
                id="author"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                className="col-span-3 input"
                placeholder="(Opsyonal) Juan from Pampanga"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="category" className="text-right">
                Kategorya
              </Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="col-span-3 input">
                  <SelectValue placeholder="Piliin ang kategorya" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rain">Para sa tag-ulan</SelectItem>
                  <SelectItem value="drought">Para sa tag-init</SelectItem>
                  <SelectItem value="pest">Proteksyon laban sa peste</SelectItem>
                  <SelectItem value="general">Pangkalahatang payo</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" className="btn btn-primary">
              Ibahagi
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

