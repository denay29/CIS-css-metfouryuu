import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CropInfo = {
  scientificName: string
  commonName: string
  vernacularNames: string[]
  lifeCycle: string
  reproduction: string
  growthHabit: string
  description: string
  cultivation: string
  uses: string[]
}

const cropData: { [key: string]: CropInfo } = {
  palay: {
    scientificName: "Oryza sativa L.",
    commonName: "Rice",
    vernacularNames: ["Palay", "Bigas"],
    lifeCycle: "Annual",
    reproduction: "Sexual",
    growthHabit: "Herb, 50-130 cm tall, up to 5 m long in deep-water rice",
    description:
      "Leaves are simple, in 2-ranks; blade linear, smooth to scabrous, 1-16 cm × 2-5 mm, parallel venation; lower leaves with acuminate ligules up to 40 mm, auricles often present.",
    cultivation:
      "Widely cultivated, predominantly in Central Luzon, Western Visayas, Cagayan Valley, and Ilocos Region.",
    uses: ["Food - cereal", "Feed", "Cosmetics - oil"],
  },
  mais: {
    scientificName: "Zea mays L.",
    commonName: "Corn",
    vernacularNames: ["Mais", "Gahilang", "Mañgi", "Tigi"],
    lifeCycle: "Annual",
    reproduction: "Sexual",
    growthHabit: "Herb, 1-4 m tall",
    description:
      "Leaves are simple, alternate, cauline, borne at nodes; blade linear to lanceolate, rough, 30–150 cm × 5–15 cm, with noticeable midrib.",
    cultivation: "Widely cultivated, predominantly in Cagayan Valley, Northern Mindanao, SOCCSKSARGEN, and ARMM.",
    uses: ["Food - Cereal, sugar, vegetable", "Feed - silage"],
  },
  // Add more crops here...
}

export default function CropGrowthHandbook() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCrop, setSelectedCrop] = useState<CropInfo | null>(null)

  const handleSearch = () => {
    const crop = cropData[searchTerm.toLowerCase()]
    setSelectedCrop(crop || null)
  }

  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      <h2 className="text-2xl font-bold mb-4">Gabay sa Pagtatanim ng mga Pananim</h2>
      <div className="flex mb-4">
        <Input
          type="text"
          placeholder="Maghanap ng pananim (hal. palay, mais)"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-grow mr-2"
        />
        <Button onClick={handleSearch}>Maghanap</Button>
      </div>
      {selectedCrop ? (
        <Card>
          <CardHeader>
            <CardTitle>
              {selectedCrop.commonName} ({selectedCrop.scientificName})
            </CardTitle>
            <CardDescription>Mga lokal na pangalan: {selectedCrop.vernacularNames.join(", ")}</CardDescription>
          </CardHeader>
          <CardContent>
            <p>
              <strong>Siklo ng Buhay:</strong> {selectedCrop.lifeCycle}
            </p>
            <p>
              <strong>Paraan ng Pagpaparami:</strong> {selectedCrop.reproduction}
            </p>
            <p>
              <strong>Uri ng Paglaki:</strong> {selectedCrop.growthHabit}
            </p>
            <p>
              <strong>Paglalarawan:</strong> {selectedCrop.description}
            </p>
            <p>
              <strong>Lugar ng Pagtatanim:</strong> {selectedCrop.cultivation}
            </p>
            <p>
              <strong>Mga Gamit:</strong>
            </p>
            <ul>
              {selectedCrop.uses.map((use, index) => (
                <li key={index}>{use}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      ) : (
        <p>Walang nahanap na pananim. Subukang maghanap ng iba.</p>
      )}
    </div>
  )
}

