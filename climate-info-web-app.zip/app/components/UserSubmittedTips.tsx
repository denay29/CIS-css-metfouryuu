"use client"

import { useState, useEffect } from "react"
import { ChevronUp, ChevronDown, RefreshCw } from "lucide-react"

type Tip = {
  id: number
  content: string
  author: string
  category: string
  upvotes: number
}

export default function UserSubmittedTips() {
  const [tips, setTips] = useState<Tip[]>([])
  const [loading, setLoading] = useState(true)

  const fetchTips = async () => {
    setLoading(true)
    // In a real app, this would be an API call
    const mockTips: Tip[] = [
      {
        id: 1,
        content: "Kapag tag-ulan, siguraduhing malinis ang kanal para maiwasan ang pagbaha sa taniman.",
        author: "Juan from Pampanga",
        category: "Para sa tag-ulan",
        upvotes: 15,
      },
      {
        id: 2,
        content: "Gumamit ng mulch sa paligid ng mga puno para mapanatili ang halumigmig ng lupa sa tag-init.",
        author: "Maria from Batangas",
        category: "Para sa tag-init",
        upvotes: 10,
      },
      {
        id: 3,
        content: "Mag-intercrop ng mga gulay sa pagitan ng mga puno ng niyog para sa karagdagang kita.",
        author: "Pedro from Quezon",
        category: "Pangkalahatang payo",
        upvotes: 8,
      },
    ]
    setTips(mockTips)
    setLoading(false)
  }

  useEffect(() => {
    fetchTips()
  }, [])

  const handleUpvote = (id: number) => {
    setTips(tips.map((tip) => (tip.id === id ? { ...tip, upvotes: tip.upvotes + 1 } : tip)))
  }

  const handleDownvote = (id: number) => {
    setTips(tips.map((tip) => (tip.id === id ? { ...tip, upvotes: Math.max(0, tip.upvotes - 1) } : tip)))
  }

  return (
    <div className="w-full max-w-4xl mt-8 fade-in">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-semibold text-primary dark:text-primary-dark">Mga Payo ng Magsasaka</h2>
        <button
          onClick={fetchTips}
          className="flex items-center text-primary hover:text-primary-dark transition-colors duration-300"
        >
          <RefreshCw className="w-4 h-4 mr-1" />
          I-refresh
        </button>
      </div>
      {loading ? (
        <div className="flex justify-center items-center h-32">
          <div className="loading-leaf w-12 h-12 bg-primary"></div>
        </div>
      ) : (
        <div className="space-y-4">
          {tips.map((tip) => (
            <div key={tip.id} className="card p-4">
              <p className="text-lg mb-2">{tip.content}</p>
              <div className="flex justify-between items-center text-sm text-text-light">
                <span>
                  {tip.author} • {tip.category}
                </span>
                <div className="flex items-center">
                  <button
                    onClick={() => handleUpvote(tip.id)}
                    className="mr-2 text-primary hover:text-primary-dark transition-colors duration-300"
                  >
                    <ChevronUp className="w-5 h-5" />
                  </button>
                  <span>{tip.upvotes}</span>
                  <button
                    onClick={() => handleDownvote(tip.id)}
                    className="ml-2 text-primary hover:text-primary-dark transition-colors duration-300"
                  >
                    <ChevronDown className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

