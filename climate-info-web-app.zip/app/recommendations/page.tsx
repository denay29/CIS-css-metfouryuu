import { Suspense } from "react"
import RecommendationsContent from "./RecommendationsContent"
import Loading from "./loading"

export default function RecommendationsPage({
  searchParams,
}: {
  searchParams: { location: string }
}) {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-24">
      <h1 className="text-4xl font-bold text-green-800 mb-8">Mga Rekomendasyon at Impormasyon ng Panahon</h1>
      <Suspense fallback={<Loading />}>
        <RecommendationsContent location={searchParams.location} />
      </Suspense>
    </main>
  )
}

