import { getWeatherWithPredictions } from "../lib/api"
import { generateRecommendations, generatePestWarnings } from "../lib/recommendations"
import WeatherSummary from "../components/WeatherSummary"
import TextToSpeech from "../components/TextToSpeech"
import FarmingCalendar from "../components/FarmingCalendar"

export default async function RecommendationsContent({ location }: { location: string }) {
  const { current: weatherData, predictions } = await getWeatherWithPredictions(location)
  const recommendations = generateRecommendations(weatherData)
  const pestWarnings = generatePestWarnings(weatherData)

  const recommendationsText = recommendations.map((rec) => `${rec.title}: ${rec.description}`).join(". ")
  const pestWarningsText = pestWarnings.map((warning) => warning.description).join(". ")

  return (
    <div className="w-full max-w-4xl">
      <WeatherSummary weatherData={weatherData} />
      <div className="bg-white shadow-lg rounded-lg p-6 mt-8">
        <h2 className="text-2xl font-semibold text-green-800 mb-4">Mga Rekomendasyon sa Pagsasaka</h2>
        <div className="space-y-4">
          {recommendations.map((rec, index) => (
            <div key={index} className={`p-4 rounded-lg ${rec.color}`}>
              <h3 className="font-semibold mb-2">{rec.title}</h3>
              <p>{rec.description}</p>
            </div>
          ))}
        </div>
        <TextToSpeech text={recommendationsText} />
      </div>
      {pestWarnings.length > 0 && (
        <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mt-8">
          <h2 className="text-xl font-semibold mb-2">Babala sa Peste at Sakit</h2>
          {pestWarnings.map((warning, index) => (
            <p key={index} className="mb-2">
              {warning.description}
            </p>
          ))}
          <TextToSpeech text={pestWarningsText} />
        </div>
      )}
      <div className="bg-white shadow-lg rounded-lg p-6 mt-8">
        <h2 className="text-2xl font-semibold text-green-800 mb-4">Pag-tantiya ng Panahon sa Susunod na mga Araw</h2>
        <div className="space-y-4">
          {predictions.map((prediction, index) => (
            <div key={index} className="p-4 rounded-lg bg-gray-100">
              <h3 className="font-semibold mb-2">
                {prediction.date.toLocaleDateString("tl-PH", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </h3>
              <p>Temperatura: {prediction.temperature}°C</p>
              <p>Tsansa ng Ulan: {prediction.rainfall_probability}%</p>
              <p>Hangin: {prediction.wind_speed} km/h</p>
              <p>Halumigmig: {prediction.humidity}%</p>
              <p>Kondisyon: {prediction.description}</p>
            </div>
          ))}
        </div>
      </div>
      <FarmingCalendar location={location} />
    </div>
  )
}

