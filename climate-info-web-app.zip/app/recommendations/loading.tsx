export default function Loading() {
  return <div className="text-center">Naglo-load ang mga rekomendasyon...</div>
}

