"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"

type WeatherDataPoint = {
  date: string
  temperature: number
  rainfall: number
  humidity: number
}

// Mock data for the last 30 days
const generateMockData = (): WeatherDataPoint[] => {
  const data: WeatherDataPoint[] = []
  const today = new Date()
  for (let i = 29; i >= 0; i--) {
    const date = new Date(today)
    date.setDate(date.getDate() - i)
    data.push({
      date: date.toISOString().split("T")[0],
      temperature: Math.round(Math.random() * 10 + 25),
      rainfall: Math.round(Math.random() * 50),
      humidity: Math.round(Math.random() * 40 + 60),
    })
  }
  return data
}

export default function WeatherHistoryPage() {
  const [weatherData, setWeatherData] = useState<WeatherDataPoint[]>([])
  const [selectedLocation, setSelectedLocation] = useState("Cavite")
  const [selectedMetric, setSelectedMetric] = useState("temperature")
  const [timeRange, setTimeRange] = useState("30")

  useEffect(() => {
    // In a real app, this would be an API call
    setWeatherData(generateMockData())
  }, [])

  const getMetricAverage = (metric: string) => {
    const sum = weatherData.reduce((acc, day) => acc + day[metric as keyof WeatherDataPoint], 0)
    return (sum / weatherData.length).toFixed(1)
  }

  const getMetricTrend = (metric: string) => {
    const firstHalf = weatherData.slice(0, weatherData.length / 2)
    const secondHalf = weatherData.slice(weatherData.length / 2)
    const firstAvg = firstHalf.reduce((acc, day) => acc + day[metric as keyof WeatherDataPoint], 0) / firstHalf.length
    const secondAvg =
      secondHalf.reduce((acc, day) => acc + day[metric as keyof WeatherDataPoint], 0) / secondHalf.length
    return secondAvg > firstAvg ? "tumataas" : "bumababa"
  }

  return (
    <main className="flex min-h-screen flex-col items-center p-4 md:p-24">
      <h1 className="text-4xl font-bold text-green-800 mb-8">Kasaysayan at Trend ng Panahon</h1>

      <div className="w-full max-w-4xl mb-8 flex justify-between items-center">
        <Select value={selectedLocation} onValueChange={setSelectedLocation}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Piliin ang Lokasyon" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Cavite">Cavite</SelectItem>
            <SelectItem value="Laguna">Laguna</SelectItem>
            <SelectItem value="Batangas">Batangas</SelectItem>
            <SelectItem value="Rizal">Rizal</SelectItem>
            <SelectItem value="Quezon">Quezon</SelectItem>
          </SelectContent>
        </Select>

        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Piliin ang Timeframe" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">Nakaraang 7 araw</SelectItem>
            <SelectItem value="30">Nakaraang 30 araw</SelectItem>
            <SelectItem value="90">Nakaraang 90 araw</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card className="w-full max-w-4xl mb-8">
        <CardHeader>
          <CardTitle>Buod ng Panahon sa {selectedLocation}</CardTitle>
          <CardDescription>Nakaraang {timeRange} araw</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="font-semibold">Average na Temperatura:</p>
              <p>
                {getMetricAverage("temperature")}°C ({getMetricTrend("temperature")})
              </p>
            </div>
            <div>
              <p className="font-semibold">Average na Pag-ulan:</p>
              <p>
                {getMetricAverage("rainfall")}mm ({getMetricTrend("rainfall")})
              </p>
            </div>
            <div>
              <p className="font-semibold">Average na Halumigmig:</p>
              <p>
                {getMetricAverage("humidity")}% ({getMetricTrend("humidity")})
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="w-full max-w-4xl">
        <CardHeader>
          <CardTitle>Trend ng Panahon sa Nakaraang {timeRange} Araw</CardTitle>
          <CardDescription>
            <Select value={selectedMetric} onValueChange={setSelectedMetric}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Piliin ang Sukatan" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="temperature">Temperatura</SelectItem>
                <SelectItem value="rainfall">Pag-ulan</SelectItem>
                <SelectItem value="humidity">Halumigmig</SelectItem>
              </SelectContent>
            </Select>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={weatherData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey={selectedMetric}
                stroke="#8884d8"
                name={
                  selectedMetric === "temperature"
                    ? "Temperatura (°C)"
                    : selectedMetric === "rainfall"
                      ? "Pag-ulan (mm)"
                      : "Halumigmig (%)"
                }
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="w-full max-w-4xl mt-8">
        <CardHeader>
          <CardTitle>Paliwanag ng Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            Sa nakaraang {timeRange} araw, nakikita natin na ang{" "}
            {selectedMetric === "temperature"
              ? "temperatura"
              : selectedMetric === "rainfall"
                ? "pag-ulan"
                : "halumigmig"}{" "}
            ay {getMetricTrend(selectedMetric)}.
            {selectedMetric === "temperature" &&
              " Kung patuloy ito, maaaring makaapekto ito sa mga pananim na sensitibo sa init o lamig."}
            {selectedMetric === "rainfall" &&
              " Ang pagbabago sa dami ng ulan ay maaaring mangailangan ng pag-adjust sa iyong iskedyul ng patubig."}
            {selectedMetric === "humidity" &&
              " Ang pagbabago sa halumigmig ay maaaring makaapekto sa pagtubo ng mga halaman at sa posibilidad ng pagkakaroon ng mga sakit sa halaman."}
          </p>
          <p className="mt-4">
            Tandaan: Ang mga trend na ito ay maaaring magbago sa paglipas ng panahon. Patuloy na subaybayan ang mga
            pagbabago sa panahon para sa mas mahusay na pangangalaga ng iyong mga pananim.
          </p>
        </CardContent>
      </Card>

      <div className="mt-8">
        <Button onClick={() => alert("Ipinadadala ang ulat sa iyong email...")}>
          Ipadala ang Buod ng Ulat sa Email
        </Button>
      </div>
    </main>
  )
}

