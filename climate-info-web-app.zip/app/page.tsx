import Image from "next/image"
import LocationInput from "./components/LocationInput"
import UserSubmittedTips from "./components/UserSubmittedTips"
import SubmitTipButton from "./components/SubmitTipButton"

export default function Home() {
  return (
    <div className="flex flex-col items-center">
      <div className="w-full h-96 relative mb-8 rounded-lg overflow-hidden">
        <Image
          src="/hero-image.jpg"
          alt="Lush green farm"
          layout="fill"
          objectFit="cover"
          className="transition-transform duration-10000 ease-in-out transform hover:scale-105"
        />
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white text-center px-4">Climate Information Web App</h1>
        </div>
      </div>
      <p className="text-xl mb-8 text-center max-w-2xl">
        Maligayang pagdating sa ating Climate Information Web App para sa mga magsasaka! Mangyaring piliin ang iyong
        lokasyon para makakuha ng impormasyon tungkol sa panahon at mga rekomendasyon sa pagsasaka.
      </p>
      <LocationInput />
      <UserSubmittedTips />
      <SubmitTipButton />
    </div>
  )
}

