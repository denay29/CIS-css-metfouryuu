import "./globals.css"
import { Poppins } from "next/font/google"
import Link from "next/link"
import type React from "react"
import { WelcomePopup } from "./components/WelcomePopup"

const poppins = Poppins({ subsets: ["latin"], weight: ["400", "600", "700"] })

export const metadata = {
  title: "Climate Information Web App",
  description: "Farmer-centric, AI-powered decision-support tool for climate insights",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="tl">
      <body className={`${poppins.className} bg-background text-text`}>
        <nav className="bg-primary dark:bg-primary-dark p-4 shadow-md">
          <div className="container mx-auto flex justify-between items-center">
            <Link href="/" className="text-white text-xl font-bold hover:text-gray-200 transition-colors duration-300">
              Climate Info App
            </Link>
            <div className="space-x-4">
              <Link href="/weather-history" className="text-white hover:text-gray-200 transition-colors duration-300">
                Kasaysayan ng Panahon
              </Link>
              <Link href="/crop-handbook" className="text-white hover:text-gray-200 transition-colors duration-300">
                Gabay sa Pagtatanim
              </Link>
              <Link href="/about" className="text-white hover:text-gray-200 transition-colors duration-300">
                Tungkol sa App
              </Link>
            </div>
          </div>
        </nav>
        <main className="container mx-auto px-4 py-8">{children}</main>
        <footer className="bg-primary dark:bg-primary-dark text-white p-4 mt-8">
          <div className="container mx-auto text-center">
            <p>&copy; 2023 Climate Info App. Lahat ng karapatan ay nakalaan.</p>
          </div>
        </footer>
        <WelcomePopup />
      </body>
    </html>
  )
}

